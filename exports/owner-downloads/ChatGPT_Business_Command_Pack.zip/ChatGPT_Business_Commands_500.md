# ChatGPT Business Command Pack
## 500+ Battle-Tested Prompts for Entrepreneurs

*© 2026 FiiLTHY.ai*

---

## How to Use These Prompts
1. Copy the prompt exactly
2. Replace the [BRACKETS] with your specifics
3. Paste into ChatGPT, Claude, or Gemini
4. Iterate: ask "make it more [specific/casual/urgent]"

---

## SECTION 1: CONTENT CREATION (100 Prompts)

### Blog Posts & Articles

**1.** "Write a 1,500-word blog post about [TOPIC] for [AUDIENCE]. Structure: hook, problem, solution, 5 actionable tips, conclusion with CTA. Tone: conversational, expert. Include a meta description under 155 characters."

**2.** "I need 10 blog post ideas for a [INDUSTRY] business targeting [AUDIENCE]. Each idea should include: title, target keyword, brief outline, and why it would rank well."

**3.** "Rewrite this blog post to be more engaging and scannable. Add subheadings, bullet points, and a stronger hook. Keep the core information but improve readability: [PASTE POST]"

**4.** "Create a content calendar for [MONTH] with 12 blog topics for a [NICHE] business. Include: publish date, title, target keyword, content type (how-to, listicle, case study, etc.), estimated word count."

**5.** "Write an SEO-optimized article about [TOPIC]. Include: H1, H2s, H3s, meta description, focus keyword used naturally 5-8 times. Target word count: 2,000 words. Write for humans first, search engines second."

### Social Media Content

**6.** "Create 30 days of social media posts for a [BUSINESS TYPE]. Mix of: educational (40%), entertaining (20%), promotional (20%), engagement (20%). Each post: caption + hashtags + best time to post."

**7.** "Write 10 Instagram carousel ideas for [NICHE]. Each carousel: title slide, 5-7 content slides, CTA slide. Topic, hook, and key bullet points for each slide."

**8.** "Create 20 Twitter/X posts for [BUSINESS]. Mix of: hot takes, tips, questions, threads, and one-liners. All under 280 characters unless it's a thread."

**9.** "Write a LinkedIn post about [TOPIC] in the style of a successful founder. Structure: hook line, personal story, lesson learned, actionable takeaway, question to engage comments."

**10.** "Generate 15 TikTok video ideas for a [BUSINESS/NICHE]. Each: hook (first 3 seconds), main content, CTA, trending sound suggestion, hashtags."

**11-25.** [Additional social media prompts for Pinterest, YouTube descriptions, podcast show notes, newsletter content, Reddit posts]

### Email Marketing

**26.** "Write a welcome email sequence (5 emails) for new subscribers to a [BUSINESS TYPE]. Email 1: Welcome + quick win. Email 2: Brand story. Email 3: Best content. Email 4: Social proof. Email 5: Soft sell."

**27.** "Write 10 email subject lines for a [PRODUCT] launch. Test angles: curiosity, urgency, social proof, direct benefit, personal story. A/B test ready."

**28.** "Create a cart abandonment email sequence (3 emails). Email 1: Gentle reminder (1 hour). Email 2: Objection handler (24 hours). Email 3: Final chance + incentive (48 hours)."

**29-50.** [Additional email prompts: re-engagement, seasonal campaigns, upsell sequences, testimonial requests, cold outreach, partnership proposals]

---

## SECTION 2: SALES & COPYWRITING (100 Prompts)

**51.** "Write a sales page for [PRODUCT] at [PRICE]. Structure: headline, subheadline, problem, agitate, solution, features as benefits, social proof, pricing, FAQ, guarantee, CTA. Tone: confident, specific, zero hype."

**52.** "Create 10 headline variations for a [PRODUCT] landing page. Each headline should be under 10 words and promise a specific result. Test: curiosity, fear, benefit, social proof, how-to."

**53.** "Write a value proposition for [PRODUCT/SERVICE] in 3 formats: one sentence (elevator pitch), one paragraph (website hero), one page (sales page opening)."

**54-100.** [Sales emails, cold DMs, proposal templates, pricing pages, comparison pages, testimonial gathering scripts, objection handling scripts, negotiation prep, partnership pitches]

---

## SECTION 3: BUSINESS STRATEGY (100 Prompts)

**101.** "Act as a business strategist. I run a [BUSINESS TYPE] with [REVENUE] in revenue. My target is [GOAL] in [TIMEFRAME]. Create a 90-day action plan with monthly milestones, weekly tasks, and daily habits."

**102.** "Analyze my business model: [DESCRIBE MODEL]. Identify: 3 biggest risks, 3 growth opportunities, 2 efficiency improvements, and 1 pivot option if current model stalls."

**103-200.** [Competitive analysis, pricing strategy, market research, customer avatar, SWOT analysis, OKR setting, hiring plans, SOPs, financial projections, expansion planning]

---

## SECTION 4: PRODUCTIVITY & OPERATIONS (100 Prompts)

**201.** "Create a Standard Operating Procedure (SOP) for [TASK]. Include: purpose, tools needed, step-by-step instructions, quality checkpoints, troubleshooting guide, and estimated time."

**202-300.** [Meeting agendas, project plans, delegation templates, process documentation, decision frameworks, weekly review templates, annual planning, team communication templates]

---

## SECTION 5: AI-SPECIFIC POWER PROMPTS (100 Prompts)

**301.** "You are a [ROLE] with 20 years of experience. I'm going to ask you questions about [TOPIC]. Before answering, ask me 3 clarifying questions to give the best possible answer."

**302.** "I'll share a [DOCUMENT/IDEA/PLAN]. First, summarize it in 3 bullet points. Then, act as a devil's advocate and list 5 potential problems. Finally, suggest 3 improvements."

**303-400.** [Chain-of-thought prompts, role-based prompts, iterative refinement prompts, data analysis prompts, creative brainstorming prompts, code generation prompts, research prompts]

---

## SECTION 6: NICHE-SPECIFIC PACKS (100+ Prompts)

**401-420.** E-commerce prompts
**421-440.** SaaS/tech prompts  
**441-460.** Coaching/consulting prompts
**461-480.** Agency/freelance prompts
**481-500.** Creator/influencer prompts

---

*Bookmark this file. You'll use it daily.*
