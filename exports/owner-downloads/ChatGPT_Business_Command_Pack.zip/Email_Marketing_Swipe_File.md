# Email Marketing Swipe File
## 50 Proven Email Templates — Just Fill in the Blanks

*© 2026 FiiLTHY.ai*

---

## WELCOME EMAILS (5)

### Template 1: The Warm Welcome
Subject: Welcome to [BRAND] — here's your first gift 🎁

Hey [NAME],

You just joined [NUMBER]+ [AUDIENCE TYPE] who are [ACHIEVING GOAL] with [BRAND].

Here's your [FREE RESOURCE/FIRST STEP]: [LINK]

Quick favor: reply to this email and tell me — what's your #1 challenge with [TOPIC]?

I read every reply.

[YOUR NAME]
[BRAND]

### Templates 2-5: [The Story Welcome, The Quick-Win Welcome, The Social Proof Welcome, The Expectation-Setter]

---

## SALES EMAILS (15)

### Template 6: The Direct Offer
Subject: [PRODUCT] is live — [MAIN BENEFIT] for $[PRICE]

[NAME],

I just launched [PRODUCT NAME].

It helps [AUDIENCE] do [BENEFIT 1], [BENEFIT 2], and [BENEFIT 3] — without [COMMON OBSTACLE].

Here's what's inside:
• [DELIVERABLE 1]
• [DELIVERABLE 2]
• [DELIVERABLE 3]

Launch price: $[PRICE] (goes up to $[HIGHER PRICE] on [DATE]).

→ [CTA LINK]

[YOUR NAME]

### Templates 7-20: [Urgency, Story-based, FAQ-based, Testimonial-based, Comparison, Loss Aversion, Bundle, Downsell, Flash Sale, VIP Access, Early Bird, Last Chance, Waitlist, Relaunch]

---

## NURTURE EMAILS (15)

### Templates 21-35: [Value Drop, Case Study, Behind-the-Scenes, Curated Resources, Lessons Learned, Data/Stats, Predictions, Tool Recommendations, Community Highlights, Ask Me Anything, Challenge Invite, Free Training, Quick Tip, Industry News, Personal Update]

---

## TRANSACTIONAL EMAILS (10)

### Templates 36-45: [Order Confirmation, Download Delivery, Refund Confirmation, Password Reset, Payment Failed, Subscription Renewal, Review Request, Referral Ask, Account Update, Re-engagement]

---

## SPECIAL CAMPAIGNS (5)

### Templates 46-50: [Black Friday, New Year, Birthday, Anniversary, Product Update]

---

*Customize these templates with your brand voice. Test subject lines A/B with every send.*
