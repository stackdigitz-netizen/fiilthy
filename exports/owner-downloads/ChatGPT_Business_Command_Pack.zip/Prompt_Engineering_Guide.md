# Prompt Engineering Guide
## Get 10x Better Results from Any AI

*© 2026 FiiLTHY.ai*

---

## The CORE Framework

Every great prompt has four parts:

**C** — Context: Who is the AI? What's the scenario?
**O** — Objective: What do you want it to do?
**R** — Requirements: Format, length, tone, constraints
**E** — Examples: Show it what good output looks like

### Before (Weak Prompt)
"Write me a blog post about marketing"

### After (CORE Prompt)
"You are a B2B content strategist who writes for tech startup founders. Write a 1,200-word blog post about content marketing for SaaS companies with $10K MRR. Include 5 specific tactics they can implement this week. Tone: practical, no fluff, data-backed. Format: H2 headers, bullet points, one quote from a recognized thought leader. Example of good output: [paste example]."

---

## 10 Advanced Techniques

### 1. Chain of Thought
"Think step by step before answering."
Forces the AI to reason through complex problems.

### 2. Role Assignment
"You are a [SPECIFIC EXPERT] with [X] years of experience in [SPECIFIC AREA]."

### 3. Negative Constraints
"Do NOT use buzzwords. Do NOT write more than 500 words. Do NOT use the phrase 'in today's world.'"

### 4. Output Formatting
"Format as: markdown table / numbered list / JSON / HTML / bullet points"

### 5. Iteration Prompts
"Rate this output 1-10 and tell me what would make it a 10. Then rewrite it."

### 6. Perspective Shift
"Now critique this from the perspective of a skeptical customer."

### 7. Multi-Step Tasks
"Step 1: [TASK]. Step 2: Based on Step 1, [TASK]. Step 3: Review Steps 1-2 and [FINAL TASK]."

### 8. Temperature Control
"Be creative and unconventional" (high temperature)
"Be precise and factual" (low temperature)

### 9. Examples & Anti-Examples
"Good example: [X]. Bad example: [Y]. Write something like the good example."

### 10. Revision Requests
"Keep the structure but make the tone more casual."
"Same content, but cut the word count in half."

---

*Master these 10 techniques and you'll outperform 99% of AI users.*
