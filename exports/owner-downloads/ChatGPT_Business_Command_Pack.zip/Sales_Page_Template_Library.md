# Sales Page Template Library
## 5 Proven Sales Page Structures

*© 2026 FiiLTHY.ai*

---

## Template 1: The Classic (Best for Products $27-$97)

### Section Order:
1. **Hero** — Headline + subheadline + CTA
2. **Problem** — 3 pain points your buyer faces
3. **Agitate** — What happens if they don't solve it
4. **Solution** — Your product as the answer
5. **Features → Benefits** — What's included and why it matters
6. **Social Proof** — Testimonials, numbers, logos
7. **Pricing** — Anchored against original price
8. **FAQ** — Address top 5 objections
9. **Guarantee** — Risk reversal
10. **Final CTA** — Strong closing + button

### Copy Template:

**Headline:** [SPECIFIC RESULT] in [TIMEFRAME] — Without [COMMON OBSTACLE]

**Subheadline:** The [PRODUCT TYPE] that [NUMBER]+ [AUDIENCE] use to [ACHIEVE OUTCOME]

**Problem Section:**
"If you're reading this, you probably:
• [Pain point 1]
• [Pain point 2]
• [Pain point 3]
Sound familiar? You're not alone."

**Solution Section:**
"Introducing [PRODUCT NAME] — the [PRODUCT TYPE] that takes you from [BEFORE STATE] to [AFTER STATE] in [TIMEFRAME]."

[Continue with each section template...]

---

## Template 2: The Story Page (Best for Personal Brands)
## Template 3: The Long-Form Letter (Best for Products $97+)
## Template 4: The Video Sales Page (Best for Courses)
## Template 5: The Comparison Page (Best for Competitive Markets)

---

*Pick the template that matches your product and price point. Fill in the blanks, then iterate.*
