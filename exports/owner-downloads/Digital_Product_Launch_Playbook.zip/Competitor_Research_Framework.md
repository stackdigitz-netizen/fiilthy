# Competitor Research Framework
## Know Your Market in 60 Minutes

*© 2026 FiiLTHY.ai*

---

## Step 1: Identify Top 10 Competitors (15 min)

Search these platforms for products similar to yours:
- Gumroad → gumroad.com/discover
- Etsy (digital products) → etsy.com
- Teachable / Thinkific / Podia → Google "[your topic] course"
- Twitter/X → Search "[your topic] + 'just launched'"
- Product Hunt → producthunt.com

For each, record:
| # | Name | URL | Price | Rating | Est. Sales |
|---|------|-----|-------|--------|------------|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |

---

## Step 2: Deep Dive Top 3 (30 min)

For your top 3 competitors, analyze:

### Sales Page Analysis
- What's their headline?
- What transformation do they promise?
- How do they structure their offer?
- What social proof do they show?
- What's their CTA?

### Product Analysis
- What format is it? (PDF, video, templates, etc.)
- How many files/modules?
- What's the perceived quality?
- Read their reviews — what do buyers love? What do they complain about?

### Pricing Analysis
- What's the price?
- Do they offer tiers?
- Any discounts or urgency tactics?
- What's the perceived value vs. price?

---

## Step 3: Find Your Gap (15 min)

Answer these:
1. What do ALL competitors miss?
2. What do buyers wish was included?
3. What can you do that they can't (or won't)?
4. What would make someone switch from a competitor to you?

**Your positioning: the intersection of [THEIR GAP] + [YOUR STRENGTH].**

---

*Update this analysis monthly. Markets move fast.*
