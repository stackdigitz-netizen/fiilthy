# 5-Part Email Funnel Sequences
## Plug-and-Play Email Templates for Your Launch

*© 2026 FiiLTHY.ai*

---

## SEQUENCE 1: Pre-Launch Warm-Up (3 Emails)

### Email 1 — The Seed
**Subject:** I've been working on something...
**Send:** 5 days before launch

Hey [FIRST NAME],

Quick note — I've been heads-down building something I think you'll love.

It's a [PRODUCT TYPE] that helps [TARGET AUDIENCE] do [MAIN BENEFIT] without [MAIN PAIN POINT].

I'm not ready to share details yet, but I wanted you to be first to know.

If this sounds like something you need, hit reply and say "YES" — I'll send you early access before anyone else.

Talk soon,
[YOUR NAME]

---

### Email 2 — The Tease
**Subject:** A peek behind the curtain
**Send:** 3 days before launch

Hey [FIRST NAME],

Remember that thing I mentioned? Here's a sneak peek:

[INSERT ONE SCREENSHOT OR KEY FEATURE]

It's called **[PRODUCT NAME]** and it's designed to take you from [CURRENT STATE] to [DESIRED STATE] in [TIMEFRAME].

Here's what's inside:
• [BENEFIT 1]
• [BENEFIT 2]
• [BENEFIT 3]

Launching in 3 days. Early supporters get a special price.

Stay tuned,
[YOUR NAME]

---

### Email 3 — The Countdown
**Subject:** Tomorrow.
**Send:** 1 day before launch

[FIRST NAME],

Tomorrow I'm officially launching **[PRODUCT NAME]**.

The launch price is $[PRICE] (regular price will be $[HIGHER PRICE]).

If you've been waiting for a sign to [TAKE ACTION ON THEIR GOAL], this is it.

I'll send you the link tomorrow morning. Set an alarm.

— [YOUR NAME]

---

## SEQUENCE 2: Launch Email Series (5 Emails)

### Launch Email 1 — Cart Open
**Subject:** It's live → [PRODUCT NAME]
**Send:** Launch day, morning

[Write 200 words: Problem statement → Solution → What's included → Price → CTA button → Deadline]

### Launch Email 2 — Social Proof
**Subject:** "[BUYER NAME] just said this..."
**Send:** Launch day + 1

[Share a testimonial or early result → Remind key benefits → CTA]

### Launch Email 3 — The Deep Dive
**Subject:** Here's exactly what you get
**Send:** Launch day + 2

[Detail every single deliverable → Explain the transformation step by step → CTA]

### Launch Email 4 — Objection Crusher
**Subject:** "But what if [OBJECTION]?"
**Send:** Launch day + 3

[Address top 3-5 objections directly → Guarantee reminder → CTA]

### Launch Email 5 — Final Call
**Subject:** Closing tonight at midnight
**Send:** Last day, morning + evening (send twice)

[Urgency → Recap the best testimonial → One final reason to buy → Hard deadline → CTA × 3]

---

## SEQUENCE 3: Post-Purchase Nurture (5 Emails)

### Welcome Email
**Subject:** You're in! Start here →
**Send:** Immediately after purchase

### Quick Win Email
**Subject:** Get your first result in 10 minutes
**Send:** Day 1

### Deep Feature Email
**Subject:** Most people miss this part...
**Send:** Day 3

### Testimonial Request
**Subject:** Quick favor? (takes 30 seconds)
**Send:** Day 7

### Upsell Email
**Subject:** Ready for the next level?
**Send:** Day 14

---

*Customize the [BRACKETS], add your voice, and load these into your email platform.*
