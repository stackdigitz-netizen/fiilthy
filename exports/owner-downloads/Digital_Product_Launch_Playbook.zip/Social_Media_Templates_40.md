# 40+ Social Media Templates
## Copy, Customize, Post — Ready for Any Platform

*© 2026 FiiLTHY.ai*

---

## PROBLEM AWARENESS POSTS (10)

**Template 1 — The Painful Truth**
"Most people spend [TIME] on [ACTIVITY] and get [POOR RESULT]. Here's what the top 1% do differently: [THREAD/LIST]"

**Template 2 — The "If This Is You" Post**
"If you're [COMMON FRUSTRATION], you don't need [COMMON BAD ADVICE]. You need [YOUR SOLUTION]. Here's why:"

**Template 3 — The Myth Buster**
"Myth: You need [COMMON BELIEF] to [ACHIEVE GOAL].
Reality: You need [YOUR APPROACH].
Here's the proof: [DATA/STORY]"

**Template 4 — The Cost of Inaction**
"Every day you don't [TAKE ACTION], you're leaving $[AMOUNT] on the table. Let me show you the math:"

**Template 5 — The Comparison**
"[BAD APPROACH] vs. [YOUR APPROACH]:
❌ [Bad outcome 1]  vs.  ✅ [Good outcome 1]
❌ [Bad outcome 2]  vs.  ✅ [Good outcome 2]
❌ [Bad outcome 3]  vs.  ✅ [Good outcome 3]"

**Template 6 — The Question Hook**
"Honest question: Why are you still [DOING THING THE HARD WAY] when [EASIER APPROACH] exists?"

**Template 7 — The Before/After**
"6 months ago: [STRUGGLING STATE]
Today: [THRIVING STATE]
The ONE change that made the difference: [YOUR METHOD]"

**Template 8 — The Unpopular Opinion**
"Unpopular opinion: [CONTRARIAN TAKE ABOUT YOUR NICHE]. Here's why 👇"

**Template 9 — The "I Used to Think" Post**
"I used to think [COMMON MISCONCEPTION]. Then I learned [REAL INSIGHT]. Everything changed."

**Template 10 — The Stat Hook**
"[SHOCKING STATISTIC ABOUT YOUR NICHE]. Here's what to do about it:"

---

## VALUE / TIP POSTS (15)

**Template 11-15 — Quick Tips**
"Here's a [TIME] tip that makes [BENEFIT]:
Step 1: [ACTION]
Step 2: [ACTION]
Step 3: [ACTION]
Save this for later."

**Template 16-20 — Mini Tutorials**
"How to [ACHIEVE SPECIFIC RESULT] in [TIMEFRAME]:
1. [Step with detail]
2. [Step with detail]
3. [Step with detail]
4. [Step with detail]
5. [Step with detail]
Bookmark this."

**Template 21-25 — Resource Lists**
"[NUMBER] [TOOLS/RESOURCES/STRATEGIES] I use daily:
🔹 [Resource 1] — for [USE CASE]
🔹 [Resource 2] — for [USE CASE]
🔹 [Resource 3] — for [USE CASE]
🔹 [Resource 4] — for [USE CASE]
🔹 [Resource 5] — for [USE CASE]
Which ones do you use?"

---

## SOCIAL PROOF / RESULTS (10)

**Template 26-30 — Testimonial Posts**
"'[CUSTOMER QUOTE]' — [Customer Name]

This is what happens when you [USE YOUR METHOD/PRODUCT].

[1-2 sentences about the transformation]

Link in bio if you want the same."

**Template 31-35 — Data Posts**
"Results from the last [TIMEFRAME]:
📊 [Metric 1]: [Number]
📊 [Metric 2]: [Number]
📊 [Metric 3]: [Number]

The system works. Here's how to start:"

---

## DIRECT CTA POSTS (10)

**Template 36 — Soft Sell**
"I just released [PRODUCT NAME]. It helps [AUDIENCE] do [BENEFIT]. If that's you, link in bio."

**Template 37 — Urgency Sell**
"[DISCOUNT/BONUS] ends [DEADLINE]. [PRODUCT NAME] — [ONE-LINE BENEFIT]. Grab it: [LINK]"

**Template 38 — Story Sell**
"[Short personal story about the problem you solved] → That's why I built [PRODUCT NAME]. It's live now."

**Template 39 — Results Sell**
"[CUSTOMER] used [PRODUCT] and got [RESULT] in [TIME]. Your turn: [LINK]"

**Template 40 — FAQ Sell**
"FAQ about [PRODUCT]:
Q: [Question 1] A: [Answer]
Q: [Question 2] A: [Answer]
Q: [Question 3] A: [Answer]
Ready? [LINK]"

---

*Rotate through these templates weekly. Mix 80% value / 20% promotion for best results.*
